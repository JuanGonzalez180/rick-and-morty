
export const Color = {
    primary100: "#EDE3FE",
    primary600: "#8054C7",
    primary700: "#5A3696",
    secondary600: "#64D839",
    white: "#FFFFFF",
    textSecondary: "#A7A8A8",
}